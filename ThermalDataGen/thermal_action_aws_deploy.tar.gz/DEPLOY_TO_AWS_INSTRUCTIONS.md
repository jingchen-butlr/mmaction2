# Deploy Thermal Action Detection to AWS - Step by Step Instructions

**Date**: November 12, 2025  
**Target**: AWS EC2 Instance i-02a024601a04bc5de  
**IP**: 44.248.130.76  
**User**: ec2-user

---

## Prerequisites

1. SSH access to AWS EC2 instance
2. SSH key file location (usually `~/.ssh/your-key.pem`)
3. Network access from AWS to TDengine server (35.90.244.93:6041)

---

## Quick Deployment (Recommended)

### Step 1: Copy Archive to AWS

From your Mac terminal:

```bash
cd /Users/jma/Github/Butlr/YOLOv11

# Copy the deployment archive
scp thermal_action_aws_deploy.tar.gz \
  ec2-user@44.248.130.76:/home/ec2-user/jingchen/

# Or if you need to specify SSH key:
# scp -i ~/.ssh/your-key.pem thermal_action_aws_deploy.tar.gz \
#   ec2-user@44.248.130.76:/home/ec2-user/jingchen/
```

### Step 2: SSH to AWS and Extract

```bash
# SSH to AWS
ssh ec2-user@44.248.130.76

# Or with SSH key:
# ssh -i ~/.ssh/your-key.pem ec2-user@44.248.130.76

# Navigate to project directory
cd /home/ec2-user/jingchen

# Extract archive
tar -xzf thermal_action_aws_deploy.tar.gz

# Make setup script executable
chmod +x setup_thermal_action_aws.sh

# Run setup
./setup_thermal_action_aws.sh
```

### Step 3: Generate Dataset on AWS

```bash
cd /home/ec2-user/jingchen

# Set Python path
export PYTHONPATH=/home/ec2-user/jingchen:$PYTHONPATH

# Generate dataset (takes ~3-5 seconds)
python scripts/thermal_action/generate_thermal_action_dataset.py \
  --annotation-files DataAnnotationQA/Data/Gen3_Annotated_Data_MVP/Annotations/*.json \
  --output-dir thermal_action_dataset \
  --val-split 0.2

# Validate
python scripts/thermal_action/validate_dataset.py

# Check results
cat thermal_action_dataset/dataset_info.json
```

---

## Alternative: Copy Generated Dataset

If you want to use the already generated dataset from your Mac:

```bash
# From Mac
cd /Users/jma/Github/Butlr/YOLOv11

rsync -avz --progress \
  thermal_action_dataset/ \
  ec2-user@44.248.130.76:/home/ec2-user/jingchen/thermal_action_dataset/

# Or with SSH key:
# rsync -avz --progress -e "ssh -i ~/.ssh/your-key.pem" \
#   thermal_action_dataset/ \
#   ec2-user@44.248.130.76:/home/ec2-user/jingchen/thermal_action_dataset/
```

---

## What Gets Copied

### Files Included in Archive (121 KB)

```
thermal_action_aws_deploy.tar.gz contains:

1. Scripts (scripts/thermal_action/)
   - create_hdf5_frames.py         (18K)
   - convert_annotations_to_coco.py (16K)
   - thermal_action_dataset.py      (9.8K)
   - validate_dataset.py            (18K)
   - generate_thermal_action_dataset.py (9.9K)
   - __init__.py, README.md, QUICK_COMMANDS.md

2. Data Pipeline (DataAnnotationQA/src/data_pipeline/)
   - thermal_dataset.py             (TDengine connector)
   - thermal_preprocessor.py        (Temperature processing)
   - __init__.py

3. Annotations (DataAnnotationQA/Data/.../Annotations/)
   - SL14_R1_annotation.json
   - SL14_R2_annotation.json
   - SL14_R3_annotation.json
   - SL14_R4_annotation.json
   - SL18_R1_annotation.json
   - SL18_R2_annotation.json
   - SL18_R3_annotation.json
   - SL18_R4_annotation.json

4. Documentation (cursor_readme/)
   - THERMAL_ACTION_TRAINING_GUIDE.md
   - THERMAL_ACTION_IMPLEMENTATION_SUMMARY.md
   - THERMAL_ACTION_DATASET_FINAL.md

5. Setup Files
   - setup_thermal_action_aws.sh    (Setup script)
   - AWS_EXECUTION_GUIDE.md         (This guide)
```

---

## Verification on AWS

After copying files, verify everything is present:

```bash
cd /home/ec2-user/jingchen

# Check directory structure
ls -R scripts/thermal_action/
ls -R DataAnnotationQA/src/data_pipeline/
ls DataAnnotationQA/Data/Gen3_Annotated_Data_MVP/Annotations/*.json | wc -l  # Should be 8

# Check documentation
ls cursor_readme/THERMAL_ACTION*.md

# Test TDengine connection
curl http://35.90.244.93:6041/rest/sql/thermal_sensors_pilot \
  -u root:taosdata \
  -d "SHOW TABLES"
```

---

## Dataset Generation Details

### What Happens

1. **Fetches frames** from TDengine (remote server 35.90.244.93)
2. **Creates HDF5 files** (one per sensor, ~1.1 MB each)
3. **Converts annotations** to COCO format
4. **Validates** temporal coverage and data integrity
5. **Generates** visualizations and statistics

### Expected Output

```
thermal_action_dataset/
├── frames/
│   ├── SL14_R1.h5 (1.2 MB)
│   ├── SL14_R2.h5 (1.1 MB)
│   ├── SL14_R3.h5 (1.1 MB)
│   ├── SL14_R4.h5 (1.1 MB)
│   ├── SL18_R1.h5 (1.1 MB)
│   ├── SL18_R2.h5 (1.1 MB)
│   ├── SL18_R3.h5 (1.1 MB)
│   ├── SL18_R4.h5 (1.1 MB)
│   └── sensor_info.json
├── annotations/
│   ├── train.json (314 images, 405 annotations)
│   ├── val.json (73 images, 95 annotations)
│   └── class_mapping.json
├── statistics/
│   ├── dataset_stats.json
│   ├── validation_report.json
│   └── visualizations/ (6 sample images)
└── dataset_info.json
```

---

## Integration with AlphAction/SlowFast

### Required Modifications

1. **Create dataset loader**: `AlphAction/alphaction/dataset/datasets/thermal_action.py`
2. **Register dataset**: Modify `AlphAction/alphaction/dataset/datasets/__init__.py`
3. **Create config**: `AlphAction/configs/thermal_action.yaml`
4. **Update paths**: Point to `/home/ec2-user/jingchen/thermal_action_dataset/`

### Example Dataset Loader for AlphAction

```python
# File: AlphAction/alphaction/dataset/datasets/thermal_action.py

import sys
sys.path.insert(0, '/home/ec2-user/jingchen/scripts')

from thermal_action import ThermalActionDataset, ThermalActionTransform, collate_fn
from torch.utils.data import DataLoader

class ThermalActionAVADataset:
    """Wrapper for thermal action dataset compatible with AlphAction."""
    
    def __init__(self, cfg, split='train'):
        hdf5_root = cfg.DATASETS.FRAME_ROOT
        ann_file = cfg.DATASETS.TRAIN_ANNO_PATH if split == 'train' else cfg.DATASETS.VAL_ANNO_PATH
        
        self.dataset = ThermalActionDataset(
            hdf5_root=hdf5_root,
            ann_file=ann_file,
            transforms=ThermalActionTransform(is_train=(split=='train')),
            frame_window=cfg.INPUT.FRAME_NUM
        )
    
    def __len__(self):
        return len(self.dataset)
    
    def __getitem__(self, idx):
        frames, boxes, labels, extras = self.dataset[idx]
        
        # Convert to AlphAction format
        # frames: [64, 40, 60, 3] → [3, 64, 40, 60]
        frames = frames.permute(3, 0, 1, 2)
        
        # Split into slow/fast pathways
        slow = frames[:, ::8, :, :]   # [3, 8, 40, 60]
        fast = frames[:, ::2, :, :]   # [3, 32, 40, 60]
        
        return [slow, fast], boxes, labels, extras
```

---

## Troubleshooting

### Issue: Module Not Found Error

```bash
# Set PYTHONPATH
export PYTHONPATH=/home/ec2-user/jingchen/scripts:$PYTHONPATH
export PYTHONPATH=/home/ec2-user/jingchen/DataAnnotationQA/src:$PYTHONPATH
```

### Issue: TDengine Connection Timeout

```bash
# Check security group allows outbound to 35.90.244.93:6041
# Test from AWS:
telnet 35.90.244.93 6041
# Or:
nc -zv 35.90.244.93 6041
```

### Issue: Disk Space

```bash
# Check available space
df -h /home/ec2-user

# Clean up if needed
rm -rf thermal_action_dataset/
```

### Issue: Python Version

```bash
# Check Python version (need 3.8+)
python3 --version

# Use specific version if needed
python3.11 scripts/thermal_action/generate_thermal_action_dataset.py ...
```

---

## Summary of Commands

### Full Deployment Sequence

```bash
# ==== ON MAC ====
cd /Users/jma/Github/Butlr/YOLOv11
scp thermal_action_aws_deploy.tar.gz ec2-user@44.248.130.76:/home/ec2-user/jingchen/

# ==== ON AWS ====
ssh ec2-user@44.248.130.76
cd /home/ec2-user/jingchen
tar -xzf thermal_action_aws_deploy.tar.gz
chmod +x setup_thermal_action_aws.sh
./setup_thermal_action_aws.sh

# Generate dataset
export PYTHONPATH=/home/ec2-user/jingchen:$PYTHONPATH
python scripts/thermal_action/generate_thermal_action_dataset.py \
  --annotation-files DataAnnotationQA/Data/Gen3_Annotated_Data_MVP/Annotations/*.json \
  --output-dir thermal_action_dataset \
  --val-split 0.2

# Validate
python scripts/thermal_action/validate_dataset.py

# Check results
cat thermal_action_dataset/dataset_info.json
```

---

## Next Steps After Deployment

1. ✅ Verify files copied correctly
2. ✅ Run setup script
3. ✅ Generate dataset on AWS
4. ✅ Validate dataset
5. → Integrate with AlphAction
6. → Start SlowFast training
7. → Monitor training progress
8. → Evaluate on validation set

---

**For detailed training instructions, see AWS_EXECUTION_GUIDE.md on the AWS instance after extraction.**

